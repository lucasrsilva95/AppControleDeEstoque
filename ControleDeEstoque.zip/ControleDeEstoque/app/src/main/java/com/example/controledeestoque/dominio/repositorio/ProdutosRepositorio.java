package com.example.controledeestoque.dominio.repositorio;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.controledeestoque.database.ProdOpenHelper;
import com.example.controledeestoque.dominio.entidades.Produto;

import java.util.ArrayList;
import java.util.List;

public class ProdutosRepositorio {

    private SQLiteDatabase conexao;

    public ProdutosRepositorio(Context context) {
        this.conexao = conexao;
        ProdOpenHelper openH = new ProdOpenHelper(context);
        conexao = openH.getWritableDatabase();
    }

    public void inserir(Produto produto){

        ContentValues cVal = new ContentValues();
        cVal.put("NOME", produto.nome);
        cVal.put("CATEGORIA", produto.categoria);
        cVal.put("PRECO", produto.preço);
        cVal.put("DURACAO",produto.duracao);
        String historico = convertArrayString(produto.historico);
        cVal.put("HISTORICO",convertArrayString(produto.historico));

        conexao.insertOrThrow("PRODUTOS",null,cVal);

    }

    public void alterar(Produto produto){

        ContentValues cVal = new ContentValues();
        cVal.put("NOME", produto.nome);
        cVal.put("CATEGORIA", produto.categoria);
        cVal.put("PRECO", produto.preço);
        cVal.put("DURACAO",produto.duracao);
        cVal.put("HISTORICO",convertArrayString(produto.historico));

        String[] parametros = new String[1];
        parametros[0] = Integer.toString(produto.codigo);
        conexao.update("PRODUTOS",cVal,"CODIGO = ?",parametros);

    }

    public void exclir(int codigo){
        String[] parametros = new String[1];
        parametros[0] = Integer.toString(codigo);

        conexao.delete("PRODUTOS","CODIGO = ?", parametros);
    }

    public List<Produto> buscarTodos(){
        List<Produto> produtos = new ArrayList<>();
        StringBuilder sql = new StringBuilder();
        sql.append("   SELECT CODIGO, NOME, CATEGORIA, PRECO, DURACAO, HISTORICO");
        sql.append("   FROM PRODUTOS");
        Cursor resultado = conexao.rawQuery(sql.toString(),null);
        if (resultado.getCount() > 0){
            resultado.moveToFirst();
            do{
                Produto prod = new Produto();
                prod.codigo = resultado.getInt(resultado.getColumnIndexOrThrow("CODIGO"));
                prod.nome = resultado.getString(resultado.getColumnIndexOrThrow("NOME"));
                prod.categoria = resultado.getString(resultado.getColumnIndexOrThrow("CATEGORIA"));
                prod.preço = resultado.getInt(resultado.getColumnIndexOrThrow("PRECO"));
                prod.duracao = resultado.getInt(resultado.getColumnIndexOrThrow("DURACAO"));
                prod.historico = converterStringArray(resultado.getString(resultado.getColumnIndexOrThrow("HISTORICO")));

                produtos.add(prod);
            }while(resultado.moveToNext());
        }
        return produtos;

    }

    public Produto buscarprod(int codigo){

        Produto prod = new Produto();

        StringBuilder sql = new StringBuilder();
        sql.append("SELECT CODIGO, NOME, CATEGORIA, PRECO, DURACAO, HISTORICO");
        sql.append(" FROM PRODUTOS");
        sql.append(" WHERE CODIGO = ?");

        String[] parametros = new String[1];
        parametros[0] = Integer.toString(codigo);

        Cursor resultado = conexao.rawQuery(sql.toString(),parametros);

        if (resultado.getCount() > 0){
            resultado.moveToFirst();

            prod.codigo = resultado.getInt(resultado.getColumnIndexOrThrow("CODIGO"));
            prod.nome = resultado.getString(resultado.getColumnIndexOrThrow("NOME"));
            prod.categoria = resultado.getString(resultado.getColumnIndexOrThrow("CATEGORIA"));
            prod.preço = resultado.getInt(resultado.getColumnIndexOrThrow("PRECO"));
            prod.duracao = resultado.getInt(resultado.getColumnIndexOrThrow("DURACAO"));
            prod.historico = converterStringArray(resultado.getString(resultado.getColumnIndexOrThrow("HISTORICO")));
            return prod;
        }
        return null;
    }

    public void limparLista(){
        String[] parametros = new String[1];
        conexao.delete("PRODUTOS",null,null);
    }

    public void novaLista(List<Produto> produtos){
        limparLista();
        for (Produto prod:produtos){
            inserir(prod);
        }
    }

    public String[] converterStringArray(String s){
        String[] array ;
        array = s.split(",");
        return array;
    }

    public String convertArrayString(String[] ar){
        if(ar.length > 0) {
            String result = ar[0];
            for (int i = 1; i < ar.length; i++) {
                result = result.concat("," + ar[i]);
            }
            return result;
        }
        return null;
    }
}
