package com.example.controledeestoque.dominio.entidades;

import java.io.Serializable;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

public class Produto implements Serializable {
    public int codigo;
    public String nome;
    public String categoria;
    public double preço;
    public int duracao;
    public String[] historico;

}
