package com.example.controledeestoque.database;

public class ScriptDLL {


    public static String getCreateTableProduto(){

        StringBuilder sql = new StringBuilder();

        sql.append("  CREATE TABLE PRODUTOS (");
        sql.append("  CODIGO INTEGER PRIMARY KEY AUTOINCREMENT, ");
        sql.append("  NOME STRING NOT NULL, ");
        sql.append("  CATEGORIA STRING NOT NULL, ");
        sql.append("  PRECO DOUBLE NOT NULL, ");
        sql.append("  DURACAO INTEGER NOT NULL,  ");
        sql.append("  HISTORICO STRING NOT NULL )");

        return sql.toString();
    }

    public static String getCreateTableCompras(){

        StringBuilder sql = new StringBuilder();

        sql.append(" CREATE TABLE COMPRAS (");
        sql.append(" CODIGO PRIMARY KEY AUTOINCREMENT, ");
        sql.append(" DATA STRING NOT NULL, ");
        sql.append(" TOTAL DOUBLE NOT NULL, ");
        sql.append(" PRODUTOS STRING NOT NULL, ");
        sql.append(" LOCAL STRING NOT NULL ) ");

        return sql.toString();

    }
}
