package com.example.controledeestoque.dominio.entidades;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Compra implements Serializable {
    public int condigo;
    public String data;
    public List<Produto> produtos;
    public double total;
    public String local;


    public String convertProdListParaString(List<Produto> prods){
        String result = "";
        if (prods.size() > 0){
            for(Produto prod:prods){
                result = result.concat(String.format("%s;%s;%f;%d-",prod.nome,prod.categoria,prod.preço,prod.duracao));
            }
            return result;
        }
        return null;
    }

    public List<Produto> convertStringParaProdList(String s){
        List<Produto> compra = new ArrayList<>();
        String[] comp = s.split("-");
        for(int i=0;i<comp.length;i++){
            Produto prod = new Produto();
            String[] cat = comp[i].split(";");
            prod.nome = cat[0];
            prod.categoria = cat[1];
            prod.preço = Double.parseDouble(cat[2]);
            prod.duracao = Integer.parseInt(cat[3]);
            compra.add(prod);
        }
        return compra;
    }
}
