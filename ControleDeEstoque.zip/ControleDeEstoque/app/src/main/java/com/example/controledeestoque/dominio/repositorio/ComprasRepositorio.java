package com.example.controledeestoque.dominio.repositorio;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.controledeestoque.dominio.entidades.Compra;
import com.example.controledeestoque.dominio.entidades.Produto;

import java.util.ArrayList;
import java.util.List;

public class ComprasRepositorio {

    public SQLiteDatabase conexao;

    public void inserir(Compra compra){

        ContentValues cv = new ContentValues();
        cv.put("DATA",compra.data);
        cv.put("PRODUTOS",compra.convertProdListParaString(compra.produtos));
        cv.put("TOTAL",compra.total);
        cv.put("LOCAL",compra.local);

        conexao.insertOrThrow("COMPRAS",null,cv);
    }

    public void alterar(Compra compra){
        ContentValues cv = new ContentValues();
        cv.put("DATA",compra.data);
        cv.put("PRODUTOS",compra.convertProdListParaString(compra.produtos));
        cv.put("TOTAL",compra.total);
        cv.put("LOCAL",compra.local);

        String[] parametros = new String[1];
        parametros[0] = Integer.toString(compra.condigo);

        conexao.update("COMPRAS",cv,"CODIGO = ?",parametros);
    }

    public void excluir(int codigo){
        String[] parametros = new String[1];
        parametros[0] = Integer.toString(codigo);
        conexao.delete("COMPRAS","CODIGO = ?",parametros);
    }

    public List<Compra> buscarTodos(){
        List<Compra> compras= new ArrayList<>();
        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT CODIGO,DATA,PRODUTOS,TOTAL,LOCAL");
        sql.append(" FROM COMPRAS");
        Cursor resultado = conexao.rawQuery(sql.toString(),null);
        do{
            resultado.moveToFirst();
            Compra compra = new Compra();
            compra.data = resultado.getString(resultado.getColumnIndexOrThrow("DATA"));
            compra.produtos = compra.convertStringParaProdList(resultado.getString(resultado.getColumnIndexOrThrow("PRODUTOS")));
            compra.total = resultado.getInt(resultado.getColumnIndexOrThrow("TOTAL"));
            compra.local = resultado.getString(resultado.getColumnIndexOrThrow("LOCAL"));
            compras.add(compra);
        }while(resultado.moveToNext());

        return compras;
    }


    public Compra buscarCompra(int codigo){
        Compra compra = new Compra();
        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT CODIGO,DATA,PRODUTOS,TOTAL,LOCAL");
        sql.append("  FROM COMPRAS");
        sql.append("  WHERE CODIGO = ?");

        String[] parametros = new String[1];
        parametros[0] = Integer.toString(codigo);

        Cursor resultado = conexao.rawQuery(sql.toString(),parametros);

        if (resultado.getCount() > 0) {
            resultado.moveToFirst();
            compra.data = resultado.getString(resultado.getColumnIndexOrThrow("DATA"));
            compra.produtos = compra.convertStringParaProdList(resultado.getString(resultado.getColumnIndexOrThrow("PRODUTOS")));
            compra.total = resultado.getDouble(resultado.getColumnIndexOrThrow("TOTAL"));
            compra.local = resultado.getString(resultado.getColumnIndexOrThrow("LOCAL"));

            return compra;
        }
        return null;
    }

    public void limparLista(){
        String[] parametros = new String[1];
        conexao.delete("COMPRAS",null,null);
    }

    public void novaLista(List<Compra> compras){
        limparLista();
        for (Compra comp:compras){
            inserir(comp);
        }
    }


}
